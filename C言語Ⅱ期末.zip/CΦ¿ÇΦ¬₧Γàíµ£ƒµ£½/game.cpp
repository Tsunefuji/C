#include "game.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void CSV2Array(const char* fileName, double data[STAGELENGTH][DATAC]) {
    FILE* fp;
    char s[BUFFSIZE];
    errno_t error;
    error = fopen_s(&fp, fileName, "r");
    if (error != 0)
        fprintf_s(stderr, "failed to open");
    else {
        int i = 0;
        while (fgets(s, BUFFSIZE, fp) != NULL) {
            char* a;

            int j = 0;
            char delim[] = ", ";
            char* ctx;
            a = strtok_s(s, delim, &ctx);
            if (i != 0) {
                while (a != NULL) {
                    a = strtok_s(NULL, delim, &ctx);
                    data[i - 1][j] = atof(a);
                    j++;
                    if (j == 2) {
                        break;
                    }
                }
            }
            i++;
            if (i >= 301) {
                break;
            }
        }

        fclose(fp);
    }
}

const char* get_iniDirectory() {
    static char ini_filename[CHARBUFF];
    char section[CHARBUFF];
    char keyword[CHARBUFF];
    char currentDirectory[CHARBUFF];
    GetCurrentDirectory(CHARBUFF, currentDirectory);

    sprintf_s(section, "section1");
    sprintf_s(keyword, "keyword1");
    char settingFile[CHARBUFF];
    sprintf_s(settingFile, "%s\\setting.ini", currentDirectory);

    //�ǂݍ���
    if (GetPrivateProfileString(section, keyword, "none", ini_filename, CHARBUFF, settingFile) != 0) {

        return ini_filename;
    }
    else {
        fprintf_s(stdout, "%s dosen't contain [%s] %s\n", settingFile, section, keyword);
    }
}