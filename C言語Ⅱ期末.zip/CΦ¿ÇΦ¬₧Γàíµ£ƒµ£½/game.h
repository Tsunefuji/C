#pragma once
#ifndef GAME_H
#define GAME_H

#include <curses.h>
#include <Windows.h>

#define CHARBUFF 124
#define BUFFSIZE 1024
#define DATAC 2
#define STAGE 3
#define STAGELENGTH 300

struct GameData {
	int myPositiony;
	bool outFlag;
	bool clearFlag;
};
void CSV2Array(const char* fileName, double data[STAGELENGTH][DATAC]);
const char* get_iniDirectory();

#endif 

