#include <iostream>
#include <curses.h>
#include <Windows.h>
#include "game.h"

int main(void) {
    double data[STAGELENGTH][DATAC];
    CSV2Array("stage1.csv", data);

    initscr();
    cbreak();
    noecho();
    nodelay(stdscr, TRUE);

    int key;
    keypad(stdscr, TRUE);

    int locate = 0;
    
    struct GameData gameData;
    gameData.myPositiony = 14;
    gameData.outFlag = false;
    gameData.clearFlag = false;
    start_color();
    init_pair(1, COLOR_BLUE, COLOR_RED);
    init_pair(2, COLOR_BLACK, COLOR_WHITE);
    init_pair(3, COLOR_WHITE, COLOR_BLACK);

    while (1) {
        refresh();
        napms(100);
        key = getch();
        locate++;
        int judge[30] = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
        if (gameData.outFlag == false && gameData.clearFlag == false) {
            if (key == KEY_UP) {
                if (gameData.myPositiony > 0) {
                    gameData.myPositiony--;
                }
            }
            else if (key == KEY_DOWN) {
                if (gameData.myPositiony < 28) {
                    gameData.myPositiony++;
                }
            }
            else {
            }

            erase();
            attrset(COLOR_PAIR(2));
            mvaddstr(gameData.myPositiony, 5, " ");
            mvaddstr(gameData.myPositiony + 1, 5, " ");
            attrset(COLOR_PAIR(1));

            int countstage = 0;
            int x = 300 - locate;
            if (x >= 100) {
                for (int i = locate; i < locate + 100; i++) {
                    for (int y = 0; y < data[i][0]; y++) {
                        attrset(COLOR_PAIR(1));
                        mvaddstr(y, countstage, " ");
                        if (countstage == 5) {
                            judge[y] = 1;
                        }
                    }
                    for (int y = 0; y < data[i][1]; y++) {
                        attrset(COLOR_PAIR(1));
                        mvaddstr(30 - y, countstage, " ");
                        if (countstage == 5) {
                            judge[30 - y] = 1;
                        }
                    }
                    countstage++;
                }
            }
            else if (x < 100 && x>0) {
                for (int i = locate; i < locate + x; i++) {
                    for (int y = 0; y < data[i][0]; y++) {
                        attrset(COLOR_PAIR(1));
                        mvaddstr(y, countstage, " ");
                        if (countstage == 5) {
                            judge[y] = 1;
                        }
                    }
                    for (int y = 0; y < data[i][1]; y++) {
                        attrset(COLOR_PAIR(1));
                        mvaddstr(30 - y, countstage, " ");
                        if (countstage == 5) {
                            judge[30 - y] = 1;
                        }
                    }
                    countstage++;
                }
            }
            else if (x == 0) {
                gameData.clearFlag = true;
            }
            if (judge[gameData.myPositiony] == 1 || judge[gameData.myPositiony + 1] == 1) {
                gameData.outFlag = true;
            }
        }

        else if (gameData.clearFlag == true) {
            for (int i = 0; i < 30; i++) {
                for (int j = 0; j < 100; j++) {
                    attrset(COLOR_PAIR(3));
                    mvaddstr(i, j, " ");
                }
            }
            attrset(COLOR_PAIR(2));
            mvaddstr(15, 50, "GAME CLEAR");
            if (key == KEY_F(1)) {
                gameData.clearFlag = false;
                gameData.myPositiony = 14;
                locate = 0;
            }
        }
        else if (gameData.outFlag == true) {
            for (int i = 0; i < 30; i++) {
                for (int j = 0; j < 100; j++) {
                    attrset(COLOR_PAIR(3));
                    mvaddstr(i, j, " ");
                }
            }
            attrset(COLOR_PAIR(2));
            mvaddstr(15, 50, "GAME OVER");
            if (key == KEY_F(1)) {
                gameData.outFlag = false;
                gameData.myPositiony = 14;
                locate = 0;
            }
        }
    }
    return 0;

}

